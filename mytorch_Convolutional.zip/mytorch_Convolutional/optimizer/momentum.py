import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from optimizer import Optimizer

"TODO: (optional) implement Momentum optimizer"
class Momentum(Optimizer):
    def __init__(self):
        pass

    def step(self):
        pass
